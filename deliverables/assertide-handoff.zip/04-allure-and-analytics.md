# Assertide Allure reporting and analytics specification

## Integration contract

Allure Report 3 is a core evidence renderer. PostgreSQL is the product's historical analytics source; raw Allure files are not scraped from generated HTML to compute KPIs. This separation supports long retention, filtering and truthful cancellation counts without depending on report presentation internals. Raw result adapters are versioned and validated against fixtures during dependency upgrades.

Each run has its own empty raw-results directory. Keep every retry within that directory and never merge unrelated runs as retries. Give each worker a separate output path and preserve UUID attachment references when collecting into the report input. Validate paths and hashes before building. The reporter adds case identity, suite hierarchy, feature/story, owner/severity and useful steps. Playwright tracing is recognized by the Allure integration; verify trace links in the integration smoke test. [Allure Playwright setup](https://allurereport.org/docs/playwright/), [metadata reference](https://allurereport.org/docs/playwright-reference/).

Store report, integration and browser versions with each run. Allure Report 3 history uses a configured JSONL historyPath; do not apply the Allure 2 history-directory procedure. Set historyBaseUrl to the stable authenticated report address, never an expiring presigned object URL. Partition history by project, branch lineage, environment, suite/selection family and contract version. Browser is a non-excluded distinguishing parameter. Serialize history updates by stream and publish through a compare-and-swap version to prevent concurrent jobs overwriting history. Stable fullName/testCaseId and deterministic non-excluded parameters link cases; run IDs, timestamps and randomized fixture IDs must not fragment identity. [Allure history and retries](https://allurereport.org/docs/history-and-retries/).

## Evidence and status presentation

Each result opens an attempt timeline first: Attempt 1 failed → Attempt 2 passed is labeled “Passed after retry.” A final pass never hides the first failure. Tabs: Summary, Steps, Evidence, Request/response (API), History. Show source SHA, target, browser/version, worker, timings, expected/actual and failure category above the fold. Open screenshot in a keyboard-accessible lightbox. Open traces in a private viewer; download remains available subject to permission. Videos are opt-in and retain-on-failure. Large JSON bodies collapse after 200 lines and offer a redacted download.

Categories are deterministic rules in order: canceled/interrupted (execution condition, not defect), infrastructure/runner failure, authentication/authorization, timeout, schema/contract, assertion/product behavior, unknown. Keep category rule version and raw error. Rules do not assert root cause; users may annotate a diagnosis with author/time without rewriting the raw event. Allure's passed/failed/broken/skipped/unknown states may not encode every product state; the Assertide result record preserves cancellation and infrastructure distinctions. Expected failures and quarantine have explicit badges.

Report explorer groups runs with phase generating/ready/failed/expired. A ready report's download produces an immutable ZIP with checksum and generation version. A failed build provides safe logs, rebuild action and access to normalized results. Artifact expiry does not erase the run or suggest it passed. The default investigation path is Dashboard failed count → filtered History → failed Run → Result, with direct failure links where a specific run is known.

## Metric definitions

A test instance is (run, stable case, environment, UI browser or null, parameter fingerprint). Retries are attempts of one instance. Date filters select terminal run endedAt in UTC, converted to organization timezone for daily buckets. Live executions have a separate strip and never enter historical denominators. All comparative queries apply identical filters to both intervals and report missing comparable cases.

| Metric | Definition | Exclusions / interpretation |
|---|---|---|
| Total executions | Count final test instances in selected completed runs | Not attempt count; display selected, skipped and canceled separately |
| Executed denominator | passed + failed + broken final instances | Exclude skipped, canceled, expected-failure and incomplete instances; disclose excluded totals |
| Final pass rate | final passed / executed denominator ×100 | Includes recovery after retry; zero denominator displays — |
| First-attempt pass rate | instances whose first attempt passed / same executed denominator | Not interchangeable with final pass rate |
| Failed tests | Final failed + broken instances, with separate breakdown | “Product failure” uses failed only |
| Recovered-flaky rate | Instances with earlier failed attempt and final passed / executed denominator | Same-run recovery signal; does not claim every intermittent defect is flaky |
| Historically unstable cases | Case/config identities with both pass and fail over last 10 eligible runs, minimum 5 | Flag as instability candidate; code changes can explain status changes |
| Average execution duration | Mean (run endedAt − startedAt) for completed runs | Excludes queue wait, canceled and infrastructure-error runs; sample count shown |
| Test duration trend | Median/p95 sum of attempt durations per instance | Retry cost retained; filter comparable identities |
| Browser failure rate | failed+broken UI instances / executed UI instances per browser | API browser=null excluded; never compare raw failures without denominators |
| API response p95 | Nearest-rank p95 of measured completed HTTP exchanges for selected endpoints | Timeouts separately counted; method+route template grouping; show n and window |
| Frequent failures | failed+broken count per stable case/config plus rate and n | Rank count by default; display exposure to avoid misleading small samples |
| Evidence completeness | failed/broken attempts with all policy-required artifacts / eligible failed/broken attempts | Disabled capture is disclosed; missing upload and expiry have distinct reasons |

Historical aggregates refresh within 60 seconds of terminal ingestion; show dataAsOf and a delayed badge after 120 seconds. Incremental materialization keys on runId+terminalVersion to avoid duplicate counts. Backfills rebuild from normalized attempts into a new aggregate generation, then atomically swap. Raw SQL reconciliation runs against fixed fixtures and random samples in CI. Never average daily percentages: sum numerators and denominators for the selected period.

## Dashboard and chart contract

Top filters: date range, project, suite, environment, browser, status. Browser filter explains that API cases are excluded when a concrete browser is selected. Active chips can be removed individually; Reset returns to last seven days/current project/all suites. Shareable URLs contain filter IDs only, no secrets.

Cards: Total executions 2,400; Final pass 96.9%; Failed 72; Average run 2m48s; Recovered after retry 1.9%; API p95 182ms. Data is illustrative. Trend chart has first-attempt and final-pass series, denominator tooltip and a table view. Browser chart displays count and rate. Failure list links to case history. Selecting a day applies an explicit date chip and updates all historical panels. Live R-1043 is independently labeled “Live · 1 of 2 complete” and cannot be confused with the seven-day slice.

Chart empty states distinguish no runs, no matching executions and insufficient samples. API latency with n<20 is marked “small sample.” Date comparison aligns equal-length preceding intervals; DST boundaries use local calendar days and UTC query bounds. Percent change is undefined when baseline is zero; show absolute change. Export includes filter snapshot, metric definitions, generatedAt, dataAsOf and sample counts.

## Report readiness acceptance

Use fixture runs containing success, assertion failure, setup error, skip, expected failure, cancel, first-failure/retry-pass, API schema error and missing attachment. Confirm each maps to the right product state, correct Allure attempt and correct denominator. Build two compatible runs and inspect history links. Run two simultaneous report builds on one stream and assert no lost history. Open report assets under authorized and unauthorized identities, test expired access, and verify relative links/trace viewer under CSP. Kill report worker mid-upload and confirm no partial report is marked ready.
